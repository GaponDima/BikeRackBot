import logging
from aiogram import Bot, Dispatcher, executor, types
from config import load_config
from messages import get_text
from keyboards import main_keyboard

config = load_config()
bot = Bot(token=config['bot_token'])
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    lang = message.from_user.language_code if message.from_user.language_code in ['ru', 'en'] else 'en'
    await message.answer(get_text("welcome", lang), reply_markup=main_keyboard(lang))

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    executor.start_polling(dp, skip_updates=True)