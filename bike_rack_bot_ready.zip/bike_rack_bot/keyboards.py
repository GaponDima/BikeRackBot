from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def main_keyboard(lang='en'):
    kb = {
        "en": ["Book a Rack", "Pricing", "Contact"],
        "ru": ["Арендовать", "Цены", "Контакты"]
    }
    return ReplyKeyboardMarkup(resize_keyboard=True).add(*[KeyboardButton(text) for text in kb[lang]])