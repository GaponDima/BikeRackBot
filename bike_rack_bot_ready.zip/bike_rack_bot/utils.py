def calculate_price(days, daily_price, discounts):
    for threshold in sorted(discounts.keys(), reverse=True):
        if days >= threshold:
            return days * daily_price * discounts[threshold]
    return days * daily_price