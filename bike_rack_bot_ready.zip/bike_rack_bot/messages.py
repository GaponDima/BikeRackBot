import json

def get_text(key, lang='en'):
    with open(f"locale/{lang}.json", encoding="utf-8") as f:
        data = json.load(f)
    return data.get(key, key)