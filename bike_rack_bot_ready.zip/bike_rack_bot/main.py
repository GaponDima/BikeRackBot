import logging
import os
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.utils import executor

load_dotenv()  # Загружаем переменные из .env

BOT_TOKEN = os.getenv("BOT_TOKEN")
DEFAULT_LANGUAGE = os.getenv("DEFAULT_LANGUAGE", "ru")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

# Заготовка текстов (можно тоже выносить в отдельный словарь или JSON/YAML)
MESSAGES = {
    "greeting": {
        "ru": "Привет! Я помогу тебе с арендой велокреплений.",
        "en": "Hello! I will help you rent bike racks."
    },
    "help": {
        "ru": "Используй /start, чтобы начать. Я помогу с арендой.",
        "en": "Use /start to begin. I will help with rentals."
    }
}

@dp.message_handler(commands=["start"])
async def start_command(message: Message):
    greeting = MESSAGES["greeting"].get(DEFAULT_LANGUAGE, "Привет!")
    await message.answer(greeting)

@dp.message_handler(commands=["help"])
async def help_command(message: Message):
    help_text = MESSAGES["help"].get(DEFAULT_LANGUAGE, "Я помогу с арендой.")
    await message.answer(help_text)

@dp.message_handler()
async def handle_message(message: Message):
    await message.answer("Пока я умею только /start и /help. Скоро научусь больше!")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    executor.start_polling(dp, skip_updates=True)

